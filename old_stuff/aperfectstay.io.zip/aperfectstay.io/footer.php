<!--<div class="footer">
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="blog.php">Blog</a></li>
        <li><a href="about.php">About</a></li>
	</ul>
	
	<div class="connect">
		<a href="#" id="facebook">facebook</a>
		<a href="#" id="twitter">twitter</a>
	    <a href="#" id="vimeo">vimeo</a>
	</div>
</div>
-->
<div id="footer">
			<section class="container">
				<header class="major">
					<h2>Connect with us</h2>
				</header>
				<ul class="icons">
					<li><a href="http://www.facebook.com" class="fa fa-facebook" target="_blank"><span>Facebook</span></a></li>
					<li><a href="http://www.twitter.com" class="fa fa-twitter" target="_blank"><span>Twitter</span></a></li>
					<li><a href="http://www.pintrest.com" class="fa fa-dribbble" target="_blank"><span>Pinterest</span></a></li>
					<li><a href="http://www.google.com" class="fa fa-google-plus" target="_blank"><span>Google+</span></a></li>
				</ul>
				<hr />
			</section>
            
            	
		</div>